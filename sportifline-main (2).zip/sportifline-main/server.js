// server.js
const express = require('express');
const path = require('path');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// session (memory store for demo)
app.use(session({
  secret: 'change_this_secret_to_a_strong_one',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24*60*60*1000 } // 1 day
}));

// serve public files
app.use(express.static(path.join(__dirname, 'public')));

/* ----------------
   API: Register
   ---------------- */
app.post('/api/register', (req, res) => {
  const { username, password, role } = req.body;
  if (!username || !password || !role) return res.status(400).json({ error: 'Missing fields' });

  // check username exists
  const userExists = db.prepare('SELECT 1 FROM users WHERE username = ?').get(username);
  if (userExists) return res.status(400).json({ error: 'Username already taken' });

  const hash = bcrypt.hashSync(password, 10);
  const stmt = db.prepare('INSERT INTO users (username, password, role) VALUES (?, ?, ?)');
  try {
    const info = stmt.run(username, hash, role);
    return res.json({ success: true, user_id: info.lastInsertRowid });
  } catch (err) {
    console.error('Register error:', err);
    return res.status(500).json({ error: 'Server error' });
  }
});

/* ----------------
   API: Login
   ---------------- */
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Missing fields' });

  const user = db.prepare('SELECT user_id, username, password, role FROM users WHERE username = ?').get(username);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });

  const ok = bcrypt.compareSync(password, user.password);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

  // set session
  req.session.user = { id: user.user_id, username: user.username, role: user.role };
  return res.json({ success: true, role: user.role });
});

/* ----------------
   API: Logout
   ---------------- */
app.post('/api/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) return res.status(500).json({ error: 'Logout failed' });
    res.json({ success: true });
  });
});

/* ----------------
   API: current user
   ---------------- */
app.get('/api/me', (req, res) => {
  if (req.session.user) return res.json({ user: req.session.user });
  return res.json({ user: null });
});

/* ----------------
   API: list athletes (for coach/organizer)
   ---------------- */
app.get('/api/athletes', (req, res) => {
  const sess = req.session.user;
  if (!sess) return res.status(401).json({ error: 'Not authenticated' });
  if (sess.role === 'athlete') return res.status(403).json({ error: 'Forbidden' });

  const rows = db.prepare("SELECT user_id, username, created_at FROM users WHERE role = 'athlete' ORDER BY username").all();
  res.json(rows);
});

/* ---------------------------
   Events & Registrations
   --------------------------- */

// list all events (public)
app.get('/api/events', (req, res) => {
  try {
    const rows = db.prepare('SELECT event_id, name, date, location, created_at FROM events ORDER BY date').all();
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'DB error' }); }
});

// create an event (organizer only)
app.post('/api/events', (req, res) => {
  const sess = req.session.user;
  if (!sess || sess.role !== 'organizer') return res.status(403).json({ error: 'Forbidden' });
  const { name, date, location } = req.body;
  if (!name) return res.status(400).json({ error: 'Missing event name' });
  try {
    const stmt = db.prepare('INSERT INTO events (name,date,location,created_by) VALUES (?,?,?,?)');
    const info = stmt.run(name, date || null, location || null, sess.id);
    res.json({ success: true, event_id: info.lastInsertRowid });
  } catch (err) { res.status(500).json({ error: 'DB error' }); }
});

// athlete registers for an event
app.post('/api/register-event', (req, res) => {
  const sess = req.session.user;
  if (!sess || sess.role !== 'athlete') return res.status(403).json({ error: 'Forbidden - only athletes' });
  const { event_id } = req.body;
  if (!event_id) return res.status(400).json({ error: 'Missing event_id' });
  try {
    const exists = db.prepare('SELECT 1 FROM registrations WHERE event_id = ? AND athlete_id = ?').get(event_id, sess.id);
    if (exists) return res.status(400).json({ error: 'Already registered' });
    const stmt = db.prepare('INSERT INTO registrations (event_id, athlete_id) VALUES (?,?)');
    const info = stmt.run(event_id, sess.id);
    res.json({ success: true, reg_id: info.lastInsertRowid });
  } catch (err) { res.status(500).json({ error: 'DB error' }); }
});

// athlete - my registrations
app.get('/api/my-registrations', (req, res) => {
  const sess = req.session.user;
  if (!sess) return res.status(401).json({ error: 'Not authenticated' });
  if (sess.role !== 'athlete') return res.status(403).json({ error: 'Forbidden' });
  try {
    const rows = db.prepare(`
      SELECT r.reg_id, e.event_id, e.name, e.date, e.location, r.status, r.created_at
      FROM registrations r
      JOIN events e ON r.event_id = e.event_id
      WHERE r.athlete_id = ?
      ORDER BY e.date DESC
    `).all(sess.id);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'DB error' }); }
});

/* ---------------------------
   TrainLog endpoints
   --------------------------- */

// add training log (athlete)
app.post('/api/trainlog', (req, res) => {
  const sess = req.session.user;
  if (!sess || sess.role !== 'athlete') return res.status(403).json({ error: 'Forbidden - only athletes' });
  const { date, activity, duration, notes } = req.body;
  if (!date || !activity) return res.status(400).json({ error: 'Missing fields' });
  try {
    const stmt = db.prepare('INSERT INTO train_logs (athlete_id,date,activity,duration,notes) VALUES (?,?,?,?,?)');
    const info = stmt.run(sess.id, date, activity, duration || null, notes || null);
    res.json({ success: true, log_id: info.lastInsertRowid });
  } catch (err) { res.status(500).json({ error: 'DB error' }); }
});

// athlete: get my logs
app.get('/api/my-trainlogs', (req, res) => {
  const sess = req.session.user;
  if (!sess) return res.status(401).json({ error: 'Not authenticated' });
  if (sess.role !== 'athlete') return res.status(403).json({ error: 'Forbidden' });
  try {
    const rows = db.prepare('SELECT * FROM train_logs WHERE athlete_id = ? ORDER BY date DESC').all(sess.id);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'DB error' }); }
});

// get logs for a particular athlete (coach or organizer can view; athlete can view own)
app.get('/api/trainlog/:athlete_id', (req, res) => {
  const sess = req.session.user;
  if (!sess) return res.status(401).json({ error: 'Not authenticated' });
  const athlete_id = Number(req.params.athlete_id);
  if (sess.role === 'athlete' && sess.id !== athlete_id) return res.status(403).json({ error: 'Forbidden' });
  try {
    const rows = db.prepare('SELECT * FROM train_logs WHERE athlete_id = ? ORDER BY date DESC').all(athlete_id);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'DB error' }); }
});

/* ---------------------------
   Messaging endpoints
   --------------------------- */

// send a message (any role)
app.post('/api/message', (req, res) => {
  const sess = req.session.user;
  if (!sess) return res.status(401).json({ error: 'Not authenticated' });
  const { to_id, message } = req.body;
  if (!to_id || !message) return res.status(400).json({ error: 'Missing fields' });
  try {
    const stmt = db.prepare('INSERT INTO messages (from_id,to_id,message) VALUES (?,?,?)');
    const info = stmt.run(sess.id, to_id, message);
    res.json({ success: true, msg_id: info.lastInsertRowid });
  } catch (err) { res.status(500).json({ error: 'DB error' }); }
});

// get conversation with another user
app.get('/api/messages/:other_id', (req, res) => {
  const sess = req.session.user;
  if (!sess) return res.status(401).json({ error: 'Not authenticated' });
  const other = Number(req.params.other_id);
  try {
    const rows = db.prepare(`
      SELECT m.msg_id, m.from_id, m.to_id, m.message, m.sent_at, u.username AS sender_name
      FROM messages m
      JOIN users u ON m.from_id = u.user_id
      WHERE (m.from_id = ? AND m.to_id = ?) OR (m.from_id = ? AND m.to_id = ?)
      ORDER BY m.sent_at ASC
    `).all(sess.id, other, other, sess.id);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'DB error' }); }
});

/* ---------------------------
   Helpers: lists of coaches/athletes
   --------------------------- */

app.get('/api/coaches', (req, res) => {
  try {
    const rows = db.prepare("SELECT user_id, username FROM users WHERE role = 'coach' ORDER BY username").all();
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'DB error' }); }
});

app.get('/api/athletes', (req, res) => {
  try {
    const rows = db.prepare("SELECT user_id, username FROM users WHERE role = 'athlete' ORDER BY username").all();
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'DB error' }); }
});

// Add/update score for athlete
app.post('/api/score', (req, res) => {
  const sess = req.session.user;
  if (!sess || sess.role !== 'organizer') return res.status(403).json({ error: 'Forbidden' });
  const { event_id, athlete_id, total_score } = req.body;
  if (!event_id || !athlete_id || total_score == null) return res.status(400).json({ error: 'Missing fields' });
  try {
    const existing = db.prepare('SELECT * FROM scores WHERE event_id=? AND athlete_id=?').get(event_id, athlete_id);
    if (existing) {
      db.prepare('UPDATE scores SET total_score=? WHERE event_id=? AND athlete_id=?').run(total_score, event_id, athlete_id);
    } else {
      db.prepare('INSERT INTO scores (event_id,athlete_id,total_score) VALUES (?,?,?)').run(event_id, athlete_id, total_score);
    }
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: 'DB error' }); }
});

// Leaderboard (Top 3 for event)
app.get('/api/leaderboard/:event_id', (req, res) => {
  try {
    const rows = db.prepare(`
      SELECT u.username, s.total_score
      FROM scores s
      JOIN users u ON s.athlete_id = u.user_id
      WHERE s.event_id = ?
      ORDER BY s.total_score DESC
      LIMIT 3
    `).all(req.params.event_id);
    res.json(rows);
  } catch (err) { res.status(500).json({ error: 'DB error' }); }
});

// save profile
app.post('/api/profile', (req,res)=>{
  const sess = req.session.user;
  if(!sess || sess.role!=='athlete') return res.status(403).json({error:'Only athletes'});
  const { age,height,weight,sport } = req.body;
  try {
    const exists = db.prepare('SELECT * FROM profiles WHERE athlete_id=?').get(sess.id);
    if(exists){
      db.prepare('UPDATE profiles SET age=?,height=?,weight=?,sport=? WHERE athlete_id=?').run(age,height,weight,sport,sess.id);
    } else {
      db.prepare('INSERT INTO profiles (athlete_id,age,height,weight,sport) VALUES (?,?,?,?,?)').run(sess.id,age,height,weight,sport);
    }
    res.json({success:true});
  } catch(err){ res.status(500).json({error:'DB error'}); }
});

// get profile
app.get('/api/profile', (req,res)=>{
  const sess = req.session.user;
  if(!sess || sess.role!=='athlete') return res.status(403).json({error:'Only athletes'});
  const row = db.prepare('SELECT * FROM profiles WHERE athlete_id=?').get(sess.id);
  res.json(row||{});
});

// list users by role
app.get('/api/users', (req,res)=>{
  const { role } = req.query;
  try {
    let rows;
    if (role) {
      rows = db.prepare('SELECT user_id, username, role FROM users WHERE role=?').all(role);
    } else {
      rows = db.prepare('SELECT user_id, username, role FROM users').all();
    }
    res.json(rows);
  } catch(err){
    res.status(500).json({error:'DB error'});
  }
});

/* fallback */
app.get(/.*/, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});

